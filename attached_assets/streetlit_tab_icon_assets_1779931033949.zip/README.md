# Streetlit tab icon assets

Persistent bottom navigation icons only.

Files:
- streetlit-tab-explore.svg — simplified compass/navigation-arrow glyph
- streetlit-tab-walk.svg — selected Walk concept: compact path + story dot + three radiating audio lines
- streetlit-tab-saved.svg — simple bookmark glyph

Implementation notes:
- SVGs use currentColor.
- No dark/light variants are needed.
- Pass the existing active/inactive tab color token into the SVG/icon component.
- Do not hardcode orange or inactive colors in the SVG files.
- All icons use viewBox 0 0 24 24, stroke width 2.25, rounded caps/joins, and no text.

Do not use these to change Explore header logo, app icon, splash, Walk Mode logic, discovery behavior, map behavior, backend, or GitHub sync.
